#include <stdio.h>
#include <stdlib.h>

int main() {
	char c1, c2;

	printf("enter first char: ");
	scanf(" %c",&c1);
	/*Space before buffer is whitespace, clears return characters allowing for input */
	printf("enter second char: ");
	scanf(" %c",&c2);

	printf("1st %c 2nd %c",c1,c2);

	printf("\n I am \"The Jonkeler\" wel cum to my twisted mind");
	printf("Hello bro today we open kali linux");
	system("hack the cia");
}