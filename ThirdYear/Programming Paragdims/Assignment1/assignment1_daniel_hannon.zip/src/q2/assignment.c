#include <stdio.h>
#include "linkedList.h"
#include "tests.h"

int main(int arg, char* argc[]){
  runTests();
  return 0;
}
