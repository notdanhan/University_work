
/**
 * Write a description of interface Status here.
 *
 * @author Daniel Hannon
 * @version Final
 */
public interface Status
{
    public boolean getAvailability();
    public void setAvailability(boolean isAvailable);
}
