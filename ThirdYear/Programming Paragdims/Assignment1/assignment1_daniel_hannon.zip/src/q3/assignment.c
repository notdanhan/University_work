#include <stdio.h>
#include "genericLinkedList.h"
#include "tests.h"

int main(int arg, char* argc[]){
  runTests();
  return 0;
}
