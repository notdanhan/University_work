package assignment3_v2;

public class NoDataException extends Exception {
	private static final long serialVersionUID = 4126773047490024275L;

	public NoDataException(String message) {
		super(message);
	}
}
